import time
import pyrebase
import pandas as pd
import re

firebaseConfig = {
  "apiKey": "AIzaSyCdrPfk5N4suX5vNBYQaSmovXGBc39gdqE",
  "authDomain": "safetyfirstcompetition.firebaseapp.com",
  "databaseURL": "https://safetyfirstcompetition-default-rtdb.europe-west1.firebasedatabase.app",
  "projectId": "safetyfirstcompetition",
  "storageBucket": "safetyfirstcompetition.appspot.com",
  "messagingSenderId": "722457491400",
  "appId": "1:722457491400:web:df3b9032f3712fe65972fd"
}

firebase = pyrebase.initialize_app(firebaseConfig)
db = firebase.database()

df = pd.DataFrame(columns=['Timestamp','t_received','Latency', 'Latitude', 'Longitude', 'Velocity', 'Altitude'])

def extract_data(data_string):
    data = {}
    patterns = {
        'latitude': r'fused\s([-\d.]+),',
        'longitude': r'fused\s[-\d.]+,([-\d.]+)',
        'hAcc': r'hAcc=([-\d.]+)',
        'et': r'et=\+([-\d.]+)',
        'alt': r'alt=([-\d.]+)',
        'vAcc': r'vAcc=([-\d.]+)',
        'vel': r'vel=([-\d.]+)',
        'timestamp': r'Time:(\d+)' 
    }
    
    for key, pattern in patterns.items():
        match = re.search(pattern, data_string)
        if match:
            data[key] = float(match.group(1))
        else:
            data[key] = None 
    
    return data

def stream_handler(message):
    global df 
    print("Data changed!")
    print("Event:", message["event"])
    print("Path:", message["path"])
    print("Data:", message["data"])
    
    t_received = time.time()
    print("Received timestamp:", t_received)
    
    data_string = message["data"]
    extracted_data = extract_data(data_string)
    
    if extracted_data['timestamp'] is not None:
        time_value = extracted_data['timestamp'] / 1000
        latency = t_received - time_value
        print("Extracted Time value:", time_value)
    else:
        print("No Time value found in the string.")
        time_value = None
        latency = None

    if message["data"] is not None:
        new_row = pd.DataFrame({
            'Latency': [latency],
            'Timestamp': [time_value],
            't_received': [t_received],
            'Latitude': [extracted_data.get('latitude')],
            'Longitude': [extracted_data.get('longitude')],
            'Velocity': [extracted_data.get('vel')],
            'Altitude': [extracted_data.get('alt')],
        })
        df = pd.concat([df, new_row], ignore_index=True)
        df.to_csv('data.csv',sep = ';', index=False)
        
        print(df)
    else:
        print("Received data is None, skipping append.")

my_stream = db.child("location").stream(stream_handler)

try:
    while True:
        time.sleep(1)
except KeyboardInterrupt:
    my_stream.close()

    

